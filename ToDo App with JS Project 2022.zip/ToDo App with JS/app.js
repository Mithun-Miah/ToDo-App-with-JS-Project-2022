let add = document.getElementById("add");

add.addEventListener('click', function() {
    let input = document.getElementById("input").value;
    let OlItem = document.getElementById("OlItem");
    let text = document.createTextNode(input);
    let newItem = document.createElement("li");
    if(input == ""){
        alert("Please Type Something");
    }else{
        newItem.appendChild(text);
        OlItem.appendChild(newItem);
    }
    // newItem.appendChild(text);
    // OlItem.appendChild(newItem);

});